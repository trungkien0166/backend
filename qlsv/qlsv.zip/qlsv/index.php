<?php 
// Điều hướng website đi đến thư mục student
header('location:student');